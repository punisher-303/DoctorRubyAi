import { EmailDashboard } from "@/components/email/email"

export default function EmailPage() {
  return <EmailDashboard />
}
