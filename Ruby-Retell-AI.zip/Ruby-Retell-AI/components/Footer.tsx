'use client';

import Link from 'next/link';
import { Facebook, Instagram, Twitter } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-black/90 text-white py-8 md:py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
              
          {/* Contact Info */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold">About Us</h3>
            <ul className="space-y-2">
              <li className="text-gray-400 text-sm">Real Time Ai Web</li>
              <li className="text-gray-400 text-sm">Anand PM</li>
              <li className="text-gray-400 text-sm">Muvattupuzha , Kerala , India</li>
              <li className="text-gray-400 text-sm">Phone: (+91)9061363103</li>
              <li className="text-gray-400 text-sm">Email: doceditorgfx@gmail.com</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col sm:flex-row justify-between items-center space-y-4 sm:space-y-0">
            <p className="text-gray-400 text-xs">
              &copy; {new Date().getFullYear()} AI Assistant. All rights reserved by Anand PM.
            </p>
            <div className="flex flex-wrap justify-center sm:justify-end gap-4 sm:gap-6">
              <Link href="/privacy" className="text-gray-400 hover:text-[#00ff8f] text-xs transition-colors">
                Privacy Policy
              </Link>
              <Link href="/terms" className="text-gray-400 hover:text-[#00ff8f] text-xs transition-colors">
                Terms of Service
              </Link>
              <Link href="/sitemap" className="text-gray-400 hover:text-[#00ff8f] text-xs transition-colors">
                Sitemap
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
